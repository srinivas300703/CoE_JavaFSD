import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:dropdown_button2/dropdown_button2.dart';

class CurrencyConverter extends StatefulWidget {
  const CurrencyConverter({super.key});

  @override
  _CurrencyConverterState createState() => _CurrencyConverterState();
}

class _CurrencyConverterState extends State<CurrencyConverter> {
  final String apiKey = "5400004a86cf518e1664b2fc"; 
  late String apiUrl;

  List<String> currencies = [];
  Map<String, dynamic> exchangeRates = {};

  String fromCurrency = "USD";
  String toCurrency = "INR";
  double amount = 1.0;
  double convertedAmount = 0.0;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    apiUrl = "https://v6.exchangerate-api.com/v6/$apiKey/latest/";
    fetchCurrencies();
  }

  Future<void> fetchCurrencies() async {
    final response = await http.get(Uri.parse("$apiUrl/USD"));
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      setState(() {
        exchangeRates = data["conversion_rates"];
        currencies = exchangeRates.keys.toList();
        isLoading = false;
        convertCurrency();
      });
    } else {
      setState(() {
        isLoading = false;
      });
    }
  }

  void convertCurrency() {
    if (exchangeRates.containsKey(fromCurrency) &&
        exchangeRates.containsKey(toCurrency)) {
      setState(() {
        double rate = exchangeRates[toCurrency] / exchangeRates[fromCurrency];
        convertedAmount = amount * rate;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Currency Converter")),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.blue, Colors.purple],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child:
            isLoading
                ? const Center(child: CircularProgressIndicator())
                : Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      const Text(
                        "Convert Currencies Instantly",
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                      const SizedBox(height: 20),

                      // Amount Input Field
                      TextField(
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(
                          labelText: "Enter Amount",
                          filled: true,
                          fillColor: Colors.white,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          prefixIcon: const Icon(Icons.monetization_on),
                        ),
                        onChanged: (value) {
                          setState(() {
                            amount = double.tryParse(value) ?? 1.0;
                            convertCurrency();
                          });
                        },
                      ),
                      const SizedBox(height: 20),

                      // Currency Dropdowns
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: _buildDropdown(fromCurrency, (newValue) {
                              setState(() {
                                fromCurrency = newValue!;
                                convertCurrency();
                              });
                            }),
                          ),
                          const SizedBox(width: 10),
                          const Icon(
                            Icons.swap_horiz,
                            size: 30,
                            color: Colors.white,
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: _buildDropdown(toCurrency, (newValue) {
                              setState(() {
                                toCurrency = newValue!;
                                convertCurrency();
                              });
                            }),
                          ),
                        ],
                      ),

                      const SizedBox(height: 30),

                      // Converted Amount Display
                      Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.9),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Column(
                          children: [
                            const Text(
                              "Converted Amount",
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 10),
                            Text(
                              "$convertedAmount $toCurrency",
                              style: const TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                                color: Colors.deepPurple,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
      ),
    );
  }

  Widget _buildDropdown(String value, Function(String?) onChanged) {
    return DropdownButtonHideUnderline(
      child: DropdownButton2<String>(
        isExpanded: true,
        items:
            currencies
                .map(
                  (currency) => DropdownMenuItem<String>(
                    value: currency,
                    child: Text(currency),
                  ),
                )
                .toList(),
        value: value,
        onChanged: onChanged,
        buttonStyleData: ButtonStyleData(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8),
            color: Colors.white,
            border: Border.all(color: Colors.black26),
          ),
        ),
        dropdownStyleData: DropdownStyleData(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8),
            color: Colors.white,
          ),
        ),
      ),
    );
  }
}
