import 'package:flutter/material.dart';
import 'weather_page.dart';
import 'news_page.dart';
import 'recipe_page.dart';
import 'currency_converter.dart';
import 'feedback_page.dart';

class HomePage extends StatefulWidget {
  final Function(bool) toggleTheme;
  final bool isDarkMode;

  const HomePage({
    super.key,
    required this.toggleTheme,
    required this.isDarkMode,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: const Text("🌎 Home Dashboard"),
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          Switch(
            value: widget.isDarkMode,
            onChanged: (value) {
              widget.toggleTheme(value);
            },
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors:
                widget.isDarkMode
                    ? [Colors.black87, Colors.black54] // Dark mode colors
                    : [
                      const Color(0xFF1E88E5),
                      const Color(0xFF1976D2),
                    ], // Light mode colors
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 90),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Text(
                "Explore Features 🚀",
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                  color: widget.isDarkMode ? Colors.white70 : Colors.white,
                ),
              ),
            ),
            const SizedBox(height: 20),

            // 🔹 Feature Cards with Navigation
            Expanded(
              child: GridView(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 15,
                  childAspectRatio: 1.1,
                ),
                children: [
                  _buildFeatureCard(
                    title: "Weather ☁️",
                    icon: Icons.cloud,
                    color: Colors.blueAccent,
                    page: const WeatherPage(),
                  ),
                  _buildFeatureCard(
                    title: "News 📰",
                    icon: Icons.article,
                    color: Colors.redAccent,
                    page: const NewsPage(),
                  ),
                  _buildFeatureCard(
                    title: "Recipes 🍽️",
                    icon: Icons.restaurant_menu,
                    color: Colors.green,
                    page: const RecipePage(),
                  ),
                  _buildFeatureCard(
                    title: "Currency 💰",
                    icon: Icons.attach_money,
                    color: Colors.orange,
                    page: const CurrencyConverter(),
                  ),
                  _buildFeatureCard(
                    title: "Feedback 📝",
                    icon: Icons.feedback,
                    color: Colors.purple,
                    page: const FeedbackPage(),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // 🔥 Feature Card with Navigation
  Widget _buildFeatureCard({
    required String title,
    required IconData icon,
    required Color color,
    required Widget page,
  }) {
    return GestureDetector(
      onTap: () {
        Navigator.push(context, MaterialPageRoute(builder: (context) => page));
      },
      child: Card(
        color: widget.isDarkMode ? Colors.grey[900] : Colors.white,
        elevation: 8,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 50, color: color),
              const SizedBox(height: 10),
              Text(
                title,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: widget.isDarkMode ? Colors.white70 : Colors.black87,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
