import 'package:flutter/material.dart';
//import 'package:flutter_html/flutter_html.dart';

class RecipeDetailPage extends StatelessWidget {
  final String title;
  final String imageUrl;
  final String instructions;

  const RecipeDetailPage({
    super.key,
    required this.title,
    required this.imageUrl,
    required this.instructions,
  });

  // Function to extract clean instructions from HTML
  List<String> parseInstructions(String htmlText) {
    final RegExp regExp = RegExp(r'<li>(.*?)<\/li>', multiLine: true);
    return regExp
        .allMatches(htmlText)
        .map((match) => match.group(1) ?? "")
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    List<String> steps = parseInstructions(instructions);

    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(15),
              child: Image.network(
                imageUrl,
                height: 250,
                width: double.infinity,
                fit: BoxFit.cover,
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              "Instructions",
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),

            // Show Instructions as List
            steps.isNotEmpty
                ? Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children:
                      steps
                          .map(
                            (step) => Padding(
                              padding: const EdgeInsets.symmetric(vertical: 8),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Icon(
                                    Icons.circle,
                                    size: 8,
                                    color: Colors.orange,
                                  ),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: Text(
                                      step,
                                      style: const TextStyle(fontSize: 16),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          )
                          .toList(),
                )
                : const Text("Instructions not available."),
          ],
        ),
      ),
    );
  }
}
