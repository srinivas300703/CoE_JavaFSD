import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class WeatherPage extends StatefulWidget {
  const WeatherPage({super.key});

  @override
  _WeatherPageState createState() => _WeatherPageState();
}

class _WeatherPageState extends State<WeatherPage> {
  String apiKey = " a2820a1f533c44babd0160918252903 ";
  String selectedCity = "Chennai";
  String temperature = "";
  String weatherCondition = "";
  String weatherIcon = "";
  bool isLoading = false;
  String backgroundImage = "assets/images/sunny.jpg"; // Default background

  List<String> cities = [
    "Chennai",
    "Mumbai",
    "Delhi",
    "Kolkata",
    "Bangalore",
    "Hyderabad",
    "Pune",
    "Ahmedabad",
    "Jaipur",
    "Lucknow",
  ];

  // Function to get weather details
  Future<void> fetchWeather() async {
    setState(() {
      isLoading = true;
    });

    final url = Uri.parse(
      "http://api.weatherapi.com/v1/current.json?key=$apiKey&q=$selectedCity&aqi=no",
    );

    try {
      final response = await http.get(url);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          temperature = "${data['current']['temp_c']}°C";
          weatherCondition = data['current']['condition']['text'];
          weatherIcon = "https:${data['current']['condition']['icon']}";

          double temp = data['current']['temp_c'];
          if (temp > 30) {
            backgroundImage = "assets/images/sunny.jpg";
          } else if (temp > 20) {
            backgroundImage = "assets/images/cloudy.jpg";
          } else {
            backgroundImage = "assets/images/rainy.jpg";
          }

          isLoading = false;
        });
      } else {
        setState(() {
          temperature = "Error";
          weatherCondition = "Could not fetch data";
          isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        temperature = "Error";
        weatherCondition = "Check your connection";
        isLoading = false;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    fetchWeather();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true, // Makes background full screen
      appBar: AppBar(
        title: const Text('Weather Info'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Stack(
        children: [
          // Background Image
          Positioned.fill(
            child: Image.asset(backgroundImage, fit: BoxFit.cover),
          ),

          Center(
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Dropdown for selecting city
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 10,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.black54,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: DropdownButton<String>(
                      value: selectedCity,
                      dropdownColor: Colors.black,
                      onChanged: (String? newValue) {
                        setState(() {
                          selectedCity = newValue!;
                          fetchWeather();
                        });
                      },
                      items:
                          cities.map<DropdownMenuItem<String>>((String city) {
                            return DropdownMenuItem<String>(
                              value: city,
                              child: Text(
                                city,
                                style: const TextStyle(color: Colors.white),
                              ),
                            );
                          }).toList(),
                      underline: Container(), // Remove default line
                      icon: const Icon(
                        Icons.arrow_drop_down,
                        color: Colors.white,
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),

                  isLoading
                      ? const CircularProgressIndicator()
                      : Column(
                        children: [
                          // Weather Icon
                          if (weatherIcon.isNotEmpty)
                            Image.network(weatherIcon, width: 80, height: 80),
                          const SizedBox(height: 10),

                          // Temperature
                          Text(
                            temperature,
                            style: const TextStyle(
                              fontSize: 50,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),

                          // Weather Condition
                          Text(
                            weatherCondition,
                            style: const TextStyle(
                              fontSize: 22,
                              color: Colors.white70,
                            ),
                          ),
                        ],
                      ),

                  const SizedBox(height: 20),

                  // Refresh Button
                  ElevatedButton.icon(
                    onPressed: fetchWeather,
                    icon: const Icon(Icons.refresh),
                    label: const Text("Refresh Weather"),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.orangeAccent,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 20,
                        vertical: 12,
                      ),
                      textStyle: const TextStyle(fontSize: 18),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
