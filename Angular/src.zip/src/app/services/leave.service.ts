import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

interface LeaveRequest {
  id: number;
  employeeName: string;
  leaveType: string;
  startDate: string;
  endDate: string;
  status: string;
  comment:string
}

@Injectable({
  providedIn: 'root'
})
export class LeaveService {
  private apiUrl = 'http://localhost:4500/leaveRequests';

  constructor(private http: HttpClient) { }

  getLeaveRequests(): Observable<LeaveRequest[]> {
    return this.http.get<LeaveRequest[]>(this.apiUrl);
  }
  applyLeave(leaveData: any): Observable<any> {
    return this.http.post<any>(this.apiUrl, leaveData);
  }
  updateLeaveStatus(id: number, updatedData: any): Observable<any> {
    return this.http.patch(`${this.apiUrl}/${id}`, updatedData); 
  }
  
  

  }
  
  
  
  
  
  

