import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ApplyLeaveComponent } from './components/apply-leave/apply-leave.component';
import { LeaveStatusComponent } from './components/leave-status/leave-status.component';
import { AdminPanelComponent } from './components/admin-panel/admin-panel.component';
import { LoginComponent } from './components/login/login.component';
import { FilterLeavePipe } from './pipes/filter-leave.pipe';
//import { LeaveCategoryPipe } from './pipes/leave-category.pipe';


@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    ApplyLeaveComponent,
    LeaveStatusComponent,
    AdminPanelComponent,
    LoginComponent,
    FilterLeavePipe,
    //LeaveCategoryPipe,
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
