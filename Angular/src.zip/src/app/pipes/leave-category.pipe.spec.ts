import { LeaveCategoryPipe } from './leave-category.pipe';

describe('LeaveCategoryPipe', () => {
  it('create an instance', () => {
    const pipe = new LeaveCategoryPipe();
    expect(pipe).toBeTruthy();
  });
});
