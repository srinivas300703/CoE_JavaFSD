import { FilterLeavePipe } from './filter-leave.pipe';

describe('FilterLeavePipe', () => {
  it('create an instance', () => {
    const pipe = new FilterLeavePipe();
    expect(pipe).toBeTruthy();
  });
});
