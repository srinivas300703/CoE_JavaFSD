import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filterLeave',
  pure: false 
})
export class FilterLeavePipe implements PipeTransform {
  transform(leaveRequests: any[], selectedType: string): any[] {
    console.log('Filtering by:', selectedType);

    if (!leaveRequests || !selectedType || selectedType === 'all') {
      return leaveRequests;
    }

    const filtered = leaveRequests.filter(leave => {
      console.log('Checking:', leave.type); 
      return leave.type?.toLowerCase() === selectedType.toLowerCase();
    });

    console.log('Filtered Results:', filtered);
    return filtered;
  }
}
