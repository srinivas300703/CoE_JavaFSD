import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filterLeave'
})
export class FilterLeavePipe implements PipeTransform {

  transform(leaveRequests: any[], selectedType: string): any[] {
    if (!leaveRequests || !selectedType || selectedType === 'all') {
      return leaveRequests; 
    }
    return leaveRequests.filter(leave => leave.type.toLowerCase() === selectedType.toLowerCase());
  }
}
