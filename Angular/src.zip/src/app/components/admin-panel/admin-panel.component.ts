import { Component, OnInit } from '@angular/core';
import { LeaveService } from '../../services/leave.service';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
@Component({
  selector: 'app-admin-panel',
  templateUrl: './admin-panel.component.html',
  styleUrls: ['./admin-panel.component.css']
})
export class AdminPanelComponent implements OnInit {
  leaveRequests: any[] = [];
  selectedLeaveType: string = 'all';
  constructor(private leaveService: LeaveService,private authService: AuthService, private router: Router) {}

  ngOnInit() {
    this.fetchLeaveRequests();
  }

  fetchLeaveRequests() {
    this.leaveService.getLeaveRequests().subscribe(data => {
      this.leaveRequests = data.map(leave => ({
        ...leave,
        type: leave.leaveType.trim().toLowerCase() 
      }));
      console.log('Normalized leave requests:', this.leaveRequests);
    });
  }
  
  showCommentBox(leave: any, status: string) {
    leave.status = status;
    leave.showComment = true;
  }


  updateStatus(leave: any, status: string) {
    let comment = leave.comment || ''; // Preserve existing comments
    
    if (status === 'Rejected') {
      comment = prompt('Please provide a reason for rejection:', comment) || 'No comment provided';
    }
    else{
      comment = 'Approved Successfully';
    }
  
    const updatedLeave = { ...leave, status, comment };
  
    this.leaveService.updateLeaveStatus(leave.id, updatedLeave).subscribe({
      next: () => {
        this.leaveRequests = this.leaveRequests.map(req =>
          req.id === leave.id ? { ...req, status, comment, showComment: false } : req
        );
        alert(`Leave request updated to ${status} with comment: "${comment}"`);
      },
      error: err => {
        console.error("Error updating leave status:", err);
        alert("Failed to update leave request. Please check API.");
      }
    });
  }
  

  logout() {
    localStorage.removeItem('adminToken'); 
    alert("You have been logged out!");
    this.router.navigate(['/login']); 
}

  
  
  
  
  
  
}
