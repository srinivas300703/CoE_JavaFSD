import { Component, OnInit } from '@angular/core';
import { LeaveService } from '../../services/leave.service';

@Component({
  selector: 'app-leave-status',
  templateUrl: './leave-status.component.html',
  styleUrls: ['./leave-status.component.css']
})
export class LeaveStatusComponent implements OnInit {
  leaveRequests: any[] = [];

  constructor(private leaveService: LeaveService) {}

  ngOnInit() {
    this.fetchLeaveRequests();
  }

  fetchLeaveRequests() {
    this.leaveService.getLeaveRequests().subscribe(data => {
      this.leaveRequests = data;
    });
  }
}
