import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { LeaveService } from '../../services/leave.service';

@Component({
  selector: 'app-apply-leave',
  templateUrl: './apply-leave.component.html',
  styleUrls: ['./apply-leave.component.css']
})
export class ApplyLeaveComponent {
  leaveForm: FormGroup;

  constructor(private fb: FormBuilder, private leaveService: LeaveService) {
    this.leaveForm = this.fb.group({
      employeeName: ['', Validators.required],
      leaveType: ['', Validators.required],
      startDate: ['', Validators.required],
      endDate: ['', Validators.required]
    });
  }

  onSubmit() {
    if (this.leaveForm.valid) {
      const newLeaveRequest = {
        ...this.leaveForm.value,
        status: 'Pending'
      };
      
      this.leaveService.applyLeave(newLeaveRequest).subscribe(response => {
        alert('Leave request submitted successfully!');
        this.leaveForm.reset();
      });
    }
  }
}
