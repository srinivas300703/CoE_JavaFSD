import { Component, OnInit } from '@angular/core';
import { LeaveService } from '../../services/leave.service';

interface LeaveRequest {
  id: number;
  employeeName: string;
  leaveType: string;
  startDate: string;
  endDate: string;
  status: string;
  comment:string
}

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  leaveRequests: LeaveRequest[] = [];

  constructor(private leaveService: LeaveService) {}

  ngOnInit() {
    this.leaveService.getLeaveRequests().subscribe(data => {
      this.leaveRequests = data.map(leave => ({
        ...leave,
        comment: leave.comment || 'No Comment'  // ✅ Adds a default value if missing
      }));
    });
  }
}
