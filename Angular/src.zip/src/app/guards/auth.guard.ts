import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(private authService: AuthService, private router: Router) {}

  canActivate(): boolean {
    if (this.authService.isAdminLoggedIn()) {
      return true;
    } else {
      alert('Access denied. Please log in as an admin.');
      this.router.navigate(['/login']);
      return false;
    }
  }
}
